<?php /*Form web page to add sensors*/
/* Authenticity verified by auth = TRUE  */
session_start();
if ($_SESSION["auth"] != TRUE)
    header("Location:login_error.php");
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Ajout capteur</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="author" content="YSBW" />
    <meta name="description" content="SAE 23" />
    <meta name="keywords" content="HTML, CSS, PHP" />
    <link rel="stylesheet" type="text/css" href="styles/style.css" />
</head>

<body class="bg">
    <header class="hd">

        <h1>Ajout capteur</h1>

        <nav>
            <ul>
                <li><a href="index.php" class="first">Accueil</a></li>
                <li><a href="administration.php">Administration</a></li>
                <li><a href="gestion.php">Gestion </a></li>
                <li><a href="consultation.php">Consultation</a></li>
                <li><a href="gestion_de_projet.html">Gestion de projet</a></li>
            </ul>
        </nav>
    </header>

    <section>
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />

        <form action="ajcap.php" method="post" enctype="multipart/form-data">
            <fieldset>
                <legend>Ajout d'un capteur</legend>

                <label for="Nom"><strong>Nom du capteur à ajouter :</strong></label>
                <input type="text" name="Nom_Cap" id="Nom" required />
                <br />

                <label for="Type"><strong>Type du capteur à ajouter :</strong></label>
                <select name="Type_Cap" id="Type" required>
					<option value=""></option>
                    <option value="température">température</option>
                    <option value="humidité">humidité</option>
                    <option value="CO2">CO2</option>
                </select>
                <br />

                <label for="Bat"><strong>Nom du bâtiment du capteur :</strong></label>
                <select name="Nom_Bat" id="Bat" required>
                    <option value=""></option>
                    <?php
                    /* This script connects us to the database */
                    // Include the database connection file
                    include 'db.php';
                    // Retrieve data from the "Buildings" table
                    $sql = "SELECT `nom_bat` FROM `Bâtiments`";
                    $result = mysqli_query($id_bd, $sql);

                    // Check if there are query errors
                    if (!$result) {
                        echo "Erreur de requête : " . mysqli_error($id_bd);
                        // Manage the query error according to your needs
                    } else {
                        // treatment of thz request
                        while ($row = mysqli_fetch_row($result)) {
                            $nom_bat = $row[0];
                            echo '<option value="' . $nom_bat . '">' . $nom_bat . '</option>';
                        }
                    }

                    // close database connexion
                    mysqli_close($id_bd);
                    ?>
                </select>
            </fieldset>
            <div class="valid">
                <input type="submit" value="Enregistrer" />
            </div>
        </form>
    </section>

    <br />
    <br />
    <br />
    <br />
    <br />

    <footer class="hd">
        <ul>
            <li>BUT1</li>
            <li>Département Réseaux et Télécommunications</li>
            <li>IUT de BLAGNAC</li>
        </ul>
    </footer>

</body>
</html>

