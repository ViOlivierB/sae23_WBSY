<?php /*Form web page to remove buildings*/
/* Authenticity verified by auth = TRUE */
session_start(); 
if ($_SESSION["auth"]!=TRUE)
    header("Location:login_error.php");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Administration</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="author" content="YSBW" />
    <meta name="description" content="SAE 23" />
    <meta name="keywords" content="HTML, CSS, PHP" />
    <link rel="stylesheet" type="text/css" href="styles/style.css"/>
</head>

<body class="bg">
<header class="hd">
    <h1>Suppression batiment</h1>
    <nav>
        <ul>
            <li><a href="index.php" class="first">Accueil</a></li>
            <li><a href="administration.php">Administration</a></li>
            <li><a href="gestion.php">Gestion </a></li>
            <li><a href="consultation.php">Consultation</a></li>
            <li><a href="gestion_de_projet.html">Gestion de projet</a></li>
        </ul>
    </nav>
</header>
<section>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <form method="POST" action="suppbat.php">
        <fieldset>
            <legend>Sélectionnez un bâtiment à supprimer :</legend>
            <select name="nom_bat" required>
                <option value=""></option>
                <?php
                /* This script connects us to the database */
                // Include the database connection file
                include 'db.php';

                // retrieve of the table "Bâtiments"
                $sql = "SELECT `nom_bat` FROM `Bâtiments`";
                $result = mysqli_query($id_bd, $sql);

                // Vérifie errors
                if (!$result) {
                    echo "Erreur de requête : " . mysqli_error($id_bd);
                    
                } else {
                    // treatments of the errors
                    while ($row = mysqli_fetch_row($result)) {
                        $nom_bat = $row[0];
                        echo '<option value="' . $nom_bat . '">' . $nom_bat . '</option>';
                    }
                }

                // close the session at the end
                mysqli_close($id_bd);
                ?>
            </select>
            <div>
                <input type="submit" value="Enregistrer" />
            </div>
        </fieldset>
    </form>
</section>
<br />
<br />
<br />
<br />
<br />
<br />
<footer class="hd">
    <ul>
        <li>BUT1</li>
        <li>Département Réseaux et Télécommunications</li>
        <li>IUT de BLAGNAC</li>
    </ul>
</footer>
</body>
</html>

