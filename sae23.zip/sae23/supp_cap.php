<?php /*Form web page to remove sensors*/
/* Authenticity verified by auth = TRUE */
session_start(); 
if ($_SESSION["auth"]!=TRUE)
    header("Location:login_error.php");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Administration</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="author" content="YSBW" />
    <meta name="description" content="SAE 23" />
    <meta name="keywords" content="HTML, CSS, PHP" />
    <link rel="stylesheet" type="text/css" href="styles/style.css"/>
</head>

<body class="bg">
<header class="hd">
    <h1>Suppression capteur</h1>
    <nav>
        <ul>
            <li><a href="index.php" class="first">Accueil</a></li>
            <li><a href="administration.php">Administration</a></li>
            <li><a href="gestion.php">Gestion </a></li>
            <li><a href="consultation.php">Consultation</a></li>
            <li><a href="gestion_de_projet.html">Gestion de projet</a></li>
        </ul>
    </nav>
</header>
<section>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <form method="POST" action="suppcap.php">
        <fieldset>
            <legend>Sélectionnez un capteur à supprimer :</legend>
            <select name="nom" required>
                <option value=""></option>
                <?php
                /* This script connects us to the database */
                // Include the database connection file
                include 'db.php';
                // Récupérer les données de la table "Capteurs"
                $sql = "SELECT DISTINCT `nom` FROM `Capteurs`";
                $result = mysqli_query($id_bd, $sql);
                // Vérifier s'il y a des erreurs de requête
                if (!$result) {
                    echo "Erreur de requête : " . mysqli_error($id_bd);
                    // Gérer l'erreur de requête selon vos besoins
                } else {
                    // Traiter les résultats de la requête
                    while ($row = mysqli_fetch_row($result)) {
                        $nom = $row[0];
                        echo '<option value="' . $nom . '">' . $nom . '</option>';
                    }
                }

                // Fermer la connexion à la base de données
                mysqli_close($id_bd);
                ?>
            </select>
            <br />
            <br />
            <select name="type" required>
                <option value=""></option>
                <?php
                /* This script connects us to the database */
                // Include the database connection file
                include 'db.php';
                // Retrieve data from the "Sensors" table
                $sql = "SELECT DISTINCT `type` FROM `Capteurs`";
                $result = mysqli_query($id_bd, $sql);
                // Check if there are query errors
                if (!$result) {
                    echo "Erreur de requête : " . mysqli_error($id_bd);
                    // Manage the query error according to your needs
                } else {
                    // Process the query results
                    while ($row = mysqli_fetch_row($result)) {
                        $type = $row[0];
                        echo '<option value="' . $type . '">' . $type . '</option>';
                    }
                }

                // Close the database connection
                mysqli_close($id_bd);
                ?>
            </select>
            <div>
                <input type="submit" value="Enregistrer" />
            </div>
        </fieldset>
    </form>
</section>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />

<footer class="hd">
    <ul>
        <li>BUT1</li>
        <li>Département Réseaux et Télécommunications</li>
        <li>IUT de BLAGNAC</li>
    </ul>
</footer>

</body>
</html>

