<?php /* web page where all the data is shown*/
/* Start of the session */
	session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <title>Consultation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="author" content="YSBW">
  <meta name="description" content="SAE 23">
  <meta name="keywords" content="HTML, CSS, PHP">
  <link rel="stylesheet" type="text/css" href="styles/style.css">
</head>

<body class="bg">
  <header class="hd">
    <h1>CONSULTATION</h1>
    <nav>
      <ul>
        <li><a href="index.php" class="first">Accueil</a></li>
        <li><a href="administration.php">Administration</a></li>
        <li><a href="gestion.php">Gestion</a></li>
        <li><a href="#">Consultation</a></li>
        <li><a href="gestion_de_projet.html">Gestion de projet</a></li>
      </ul>
    </nav>
  </header>
<section id="first">
    <h2>Toutes les mesures mises à jour</h2>
    <p>
      Sont affichées ci-dessous les metriques correspondant à chaque Batiment.
    </p>
<?php
include("db.php");

function getMetricData($id_cap, $metric)
{
    global $id_bd;
    $query = "SELECT AVG($metric) AS average, MIN($metric) AS minimum, MAX($metric) AS maximum FROM `Mesures` WHERE id_cap = '$id_cap'";
    $result = mysqli_query($id_bd, $query) or die("Execution de la requete impossible : $query");
    $data = mysqli_fetch_assoc($result);
    return $data;
}

$query = "SELECT * FROM `Bâtiments`";
$result = mysqli_query($id_bd, $query) or die("Execution de la requete impossible : $query");

while ($row = mysqli_fetch_assoc($result)) {
    $batiment = $row['nom_bat'];
    $id_bat = $row['id_bat'];
	
	// display  the header of the table
	echo "<h3> Bâtiment : $batiment</h3>";
	echo "<table>";
	echo "<tr>";
	echo "<th>Nom du capteur</th>";
	echo "<th>Moyenne</th>";
	echo "<th>Minimum</th>";
	echo "<th>Maximum</th>";
	echo "</tr>";
	
    $query_capteurs = "SELECT * FROM `Capteurs` WHERE id_bat = '$id_bat'";
    $result_capteurs = mysqli_query($id_bd, $query_capteurs) or die("Execution de la requete impossible : $query_capteurs");

    while ($row_capteur = mysqli_fetch_assoc($result_capteurs)) {
		$capteur = $row_capteur['nom'];
		$id_cap = $row_capteur['id_cap'];
		$type_cap = $row_capteur['type'];

		// Retrieve data for all the metrics
		$Données_récupérées = getMetricData($id_cap, "Valeur");
		
		$moyenne = round($Données_récupérées['average'], 2);
		$minimum = round($Données_récupérées['minimum'], 2);
		$maximum = round($Données_récupérées['maximum'], 2);
		
		// display datas
		echo "<tr>";
		echo "<td>$capteur - $type_cap</td>";
		echo "<td>$moyenne</td>";
		echo "<td>$minimum</td>";
		echo "<td>$maximum</td>";
		echo "</tr>";
		
	}

	// end of the table
	echo "</table>";
	echo "<br />";
}

mysqli_close($id_bd);
?>



<style>
  /* Style de base pour le tableau */
  table {
    width: 100%;
    border-collapse: collapse;
  }

  /* Style pour l'en-tête du tableau */
  th {
    background-color: #f2f2f2;
    color: #333;
    font-weight: bold;
    padding: 10px;
    text-align: center;
    border: 1px solid #ccc;
  }

  /* Style pour les cellules du tableau */
  td {
    padding: 10px;
    text-align: center;
    border: 1px solid #ccc;
  }

  /* Style pour les lignes impaires du tableau */
  tr:nth-child(odd) {
    background-color: #91a8ba;
  }

  /* Style pour survoler les lignes du tableau */
  tr:hover {
    background-color: #eaeaea;
  }
</style>



</section>


		<br />
		<br />
		<br />
  <footer class="hd">
    <ul>
      <li>BUT1</li>
      <li>Département Réseaux et Télécommunications</li>
      <li>IUT de BLAGNAC</li>
    </ul>
  </footer>
</body>
</html>
