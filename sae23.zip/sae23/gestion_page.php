<?php /*Form web page to access to all the data that the administrator can see*/
session_start();

// Check if the user is authenticated
if (!isset($_SESSION["auth"]) || $_SESSION["auth"] !== true) {
    header("Location: index.php"); // Redirect to the login page if not authenticated
    exit();
}

// Retrieve the building ID from the session
$buildingId = $_SESSION["id_bat"];

// Include the necessary files and establish a database connection
include("db.php");

// Fetch the building name
$buildingQuery = "SELECT nom_bat FROM `Bâtiments` WHERE id_bat = ?";
$buildingStmt = mysqli_prepare($id_bd, $buildingQuery);
mysqli_stmt_bind_param($buildingStmt, "i", $buildingId);
mysqli_stmt_execute($buildingStmt);
$buildingResult = mysqli_stmt_get_result($buildingStmt);
$buildingRow = mysqli_fetch_assoc($buildingResult);
$buildingName = $buildingRow["nom_bat"];

// Fetch all the sensors belonging to the building
$sensorData = array();
$sensorQuery = "SELECT * FROM `Capteurs` WHERE id_bat = ?";
$sensorStmt = mysqli_prepare($id_bd, $sensorQuery);
mysqli_stmt_bind_param($sensorStmt, "i", $buildingId);
mysqli_stmt_execute($sensorStmt);
$sensorResult = mysqli_stmt_get_result($sensorStmt);

while ($sensorRow = mysqli_fetch_assoc($sensorResult)) {
    $sensorId = $sensorRow["id_cap"];
    $valuesQuery = "SELECT * FROM `Mesures` WHERE id_cap = ? ORDER BY id_mes DESC LIMIT 5";
    $valuesStmt = mysqli_prepare($id_bd, $valuesQuery);
    mysqli_stmt_bind_param($valuesStmt, "i", $sensorId);
    mysqli_stmt_execute($valuesStmt);
    $valuesResult = mysqli_stmt_get_result($valuesStmt);

    $sensorRow["Valeur"] = array();
    while ($valueRow = mysqli_fetch_assoc($valuesResult)) {
        $valueRow["Valeur"] = round($valueRow["Valeur"], 2); // Round the value to 2 decimal places
        $sensorRow["Valeur"][] = $valueRow;
    }

    $sensorData[$sensorRow["type"]][] = $sensorRow;
}

// Close the database connection
mysqli_close($id_bd);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<title>Gestion de projet</title> 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="author" content="YSBW" />
	<meta name="description" content="SAE 23" />
	<meta name="keywords" content="HTML, CSS, PHP" />
	<link rel="stylesheet" type="text/css" href="styles/style.css"/>
 </head>
 <body class="bg">

  <header  class="hd">
   
      <h1>GESTION DE PROJET</h1>
    
   <nav>
    <ul>
		   <li><a href="index.php" class="first">Accueil</a></li>
			<li><a href="administration.php">Administration</a></li>
		    <li><a href="gestion.php">Gestion </a></li>
		   <li><a href="consultation.php">Consultation</a></li>
		   <li><a href="gestion_de_projet.html">Gestion de projet</a></li>
    </ul>
   </nav>
  </header> 
<body>
    <h1> Données des capteurs du bâtiment <?php echo $buildingName; ?></h1>
    <?php foreach ($sensorData as $sensorType => $sensors): ?>
        <h2><?php echo $sensorType; ?></h2>
        <table>
            <tr>
                <th>Nom du capteur</th>
                <th>5 dernières valeurs</th>
            </tr>
            <?php foreach ($sensors as $sensor): ?>
                <tr>
                    <td><?php echo $sensor["nom"]; ?></td>
                    <td>
                        <ul class="a">
                            <?php foreach ($sensor["Valeur"] as $value): ?>
                                <li><?php echo $value["Valeur"]; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endforeach; ?>
<footer class="hd">
    <ul>
	  <li>BUT1</li>
	  <li>Département Réseaux et Télécommunications</li>
      <li>IUT de BLAGNAC</li>
	</ul> 
  </footer> 
  
  
</body>  
</html>
