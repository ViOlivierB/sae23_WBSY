<?php /*Form web page to add sensors*/
/* Authenticity verified by auth = TRUE  */
	session_start(); 
	if ($_SESSION["auth"]!=TRUE)
		header("Location:login_error.php");
?>

<!DOCTYPE html>
	<html lang="fr">
 	<head>
	<title>Administration</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="author" content="YSBW" />
  <meta name="description" content="SAE 23" />
  <meta name="keywords" content="HTML, CSS, PHP" />
  <link rel="stylesheet" type="text/css" href="styles/style.css"/>
 </head>

 	<body class="bg">
 			<header class="hd">
  
      <h1>Ajout capteur</h1>
    
   <nav>
    <ul>
		    <li><a href="index.php" class="first">Accueil</a></li>
			<li><a href="administration.php">Administration</a></li>
		    <li><a href="gestion.php">Gestion </a></li>
		    <li><a href="consultation.php">Consultation</a></li>
		    <li><a href="gestion_de_projet.html">Gestion de projet</a></li>
    </ul>
   </nav>
  </header>
<br />
		<br />
		<br />
		<br />
		<br />
		<br />	
		<br />
		<br />
		<br />
		<br />
		<br />
		<br />	
		<?php
    include("db.php");

    // Check if the request method is POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get the values from the form inputs
        $NOM_CAP = $_POST['Nom_Cap'];
        $TYPE_CAP = $_POST['Type_Cap'];
        $NOM_BAT = $_POST['Nom_Bat'];

        // Query to retrieve the ID of the selected building
        $query_batiment = "SELECT `id_bat` FROM `Bâtiments` WHERE `nom_bat` = '$NOM_BAT'";
        $result_batiment = mysqli_query($id_bd, $query_batiment);
        $row_batiment = mysqli_fetch_assoc($result_batiment);
        $ID_BAT = $row_batiment['id_bat'];

        // Insert the new sensor into the Capteurs table
        $request = "INSERT INTO `Capteurs` (`nom`, `type`, `id_bat`) VALUES ('$NOM_CAP', '$TYPE_CAP', '$ID_BAT')";
        $result = mysqli_query($id_bd, $request) or die("Execution of the query failed: $request");

        // Close the database connection
        mysqli_close($id_bd);

        // Display a success message
        echo "<p><strong>Le capteur $NOM_CAP de type $TYPE_CAP a été créé.</strong></p>";
    }
?>

			
		
		<p>
			<a class="button" href="index.php"><strong>Accueil</strong> 
			</a>
		</p>
		 
  <br />
		<br />
		<br />
		<br />
		<br /><br />
		<br />
		<br />
		<br />
		<br />
  <footer class="hd">
    <ul>
	  <li>BUT1</li>
	  <li>Département Réseaux et Télécommunications</li>
      <li>IUT de BLAGNAC</li>
	</ul>  
  </footer>

  </body> 
</html>
