<?php /*Data processing file for the form in order to access to administration of the building*/
session_start();

// Storing the value of 'login_gest' received from the request in the session variable
$_SESSION["login_gest"] = $_REQUEST["login_gest"]; 
$login = $_SESSION["login_gest"];

// Storing the value of 'mdp_gest' received from the request in the session variable
$_SESSION["mdp_gest"] = $_REQUEST["mdp_gest"];
$motdep = $_SESSION["mdp_gest"];

/* Initializing the 'auth' session variable as FALSE means that by default,
the user is not authenticated. In other words, when the session starts, the 'auth' variable is set to FALSE,
indicating that the user has not been authenticated yet.*/
$_SESSION["auth"] = FALSE;

include("db.php");

// Check if 'login_gest' and 'mdp_gest' match in the database
$request = "SELECT id_bat FROM `Bâtiments` WHERE login_gest = ? AND mdp_gest = ?";
$stmt = mysqli_prepare($id_bd, $request);
mysqli_stmt_bind_param($stmt, "ss", $login, $motdep);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result) {
    echo "Error: " . mysqli_error($id_bd);
    exit();
}

$row = mysqli_fetch_assoc($result);

if ($row) {
    // Authentication successful, set the "auth" session variable to TRUE
    $_SESSION["auth"] = true;
    $_SESSION["id_bat"] = $row["id_bat"];
    mysqli_close($id_bd);

    // Redirect to gestion_E.php
    header("Location: gestion_page.php");
    exit();
}

// Reset the session
$_SESSION = array();
session_destroy();
unset($_SESSION);
mysqli_close($id_bd);
header("Location: index.php");
?>

